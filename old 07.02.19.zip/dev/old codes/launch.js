Callback.addCallback("PostLoaded", function () {
	editorUI.open(editorUI.menu);
});