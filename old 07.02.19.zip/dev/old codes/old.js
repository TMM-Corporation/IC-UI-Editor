





/*
	edit: {
		element: function(isAdd){
			if(isAdd==true)
			editor.init.add.element();
			else
			editor.init.remove.element();
		},
		drawing: function(isAdd){
			if(isAdd==true)
			editor.init.add.element();
			else
			editor.init.remove.element();
		}
	},
*/
















/*

var f={};
for(let g = 0; 36 > g; g++)
f["__invslot" + g] = {
	type: "invSlot",
	size: 251,
	x: g % 4 * 250,
	y: 250 * parseInt(g / 4),
	index: g + 9
};
var inventory = new UI.Window({
location: {
	x: 460,
	y: 60,
	width: 230,
	height: 400,
	scrollHeight: 460
},
drawing: [{type: "background",color: android.graphics.Color.BLACK}],
elements: f
});
var editorUI = new UI.Window({
	location: {
		x: 60,
		y: 60,
		width: 880,
		height: 500,
		scrollHeight: 1000
	},

});
var gui_list = {
	standart: {
		//header: {text: {text: "UI Editor"}},
		//inventory: {width: 260, padding: 10,},
		//background: {color: android.graphics.Color.rgb(179, 179, 179),}
	},
	drawing: [{type: "background", color: null}],
	elements: {}
};*/



//FileTools.GetListOfFiles(__dir__+"gui")
